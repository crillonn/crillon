# Importing Modules
import time
import random


# Creation of Running Variables
items = []
correct_panels = []
valid_input = ['y', 'n']
Completion = 0
count_correct = 0
Game = 0
# Defining Functions


def print_pause(message):
    print(message)
    time.sleep(1)


# Introduction


def intro():
    print_pause("You awaken in the centre of a circular room and look around")
    print_pause("There are 5 enclaves along the edges of the room")
    print_pause("Each one radiating a different colored light but each had a"
                " pedestal in it's center")
    print_pause("Each pedestal contains a different colored panel")
    print_pause("You have to find a way out of here!")
# Resetting the game


def Reset():
    global Completion
    global count_correct
    if Completion == 1:
        Completion = Completion - 1
    elif count_correct == 6:
        count_correct = count_correct - 6
    correct_panels.clear()
    items.clear()
# Returning to the Centre of the room


def Centre_Return():
    global count_correct
    global Completion
    if Completion == 0:
        if count_correct == 3:
            Fight()
        else:
            Select()
    elif Completion == 1:
        print_pause("You hear a loud rumbling noise, "
                    "in the centre of the room a trapdoor appears!")
        print_pause("Congratulations! You have escaped the room!")


# Selecting an enclave
def Select():
    print_pause("What would you like to do? \n")
    print_pause("1. Go to Green Enclave")
    print_pause("2. Go to Red Enclave")
    print_pause("3. Go to Blue Enclave")
    print_pause("4. Go to White Enclave")
    print_pause("5. Go to Yellow Enclave")
    choice = input("Please enter the number of the option you decide \n")
    if choice == '1':
        green_room()
    elif choice == '2':
        red_room()
    elif choice == '3':
        blue_room()
    elif choice == '4':
        white_room()
    elif choice == '5':
        yellow_room()
    else:
        print_pause("What you have decided is not possible")
        Centre_Return()


# Fight Event At Half Way
def Fight():
    global count_correct
    while count_correct == 3:
        print_pause("You hear a whispy voice all around you")
        print_pause(" 'You believe it to be as simple as this?' ")
        print_pause("A frail and ghostly figure appears in front of you")
        print_pause(" 'You may only continue should you win a"
                    "dice roll against me'")
        print_pause("He hands you a die, now roll!")
        ghost_roll = random.randint(1, 6)
        player_roll = random.randint(1, 6)
        print_pause("The ghost rolled "+str(ghost_roll))
        print_pause("You rolled "+str(player_roll))
        if ghost_roll < player_roll:
            print_pause(" 'Well Played, you may proceed'")
            count_correct += 3
        else:
            print_pause(" 'Hahaha! Let's try that again")
    Centre_Return()


# Winning Scenario
def Win():
    global Completion
    if "green" in correct_panels:
        if "red" in correct_panels:
            if "blue" in correct_panels:
                if "white" in correct_panels:
                    if "yellow" in correct_panels:
                        Completion += 1


# Room Options
def green_room():
    global count_correct
    print_pause("You approach the greenly lit enclave")
    if "blue" in items and "green" not in correct_panels:
        print_pause("The pedestal is empty")
        Place_Panel = input("Would you like to place a new panel"
                            "in the pedestal? Y/N \n ").lower()
        if Place_Panel == "y":
            print_pause("You search through your inventory for an "
                        "appropriate panel...")
            if "green" in items:
                print_pause("You place a green panel into the pedestal")
                count_correct += 1
                correct_panels.append("green")
            else:
                print_pause("Nothing you have seems appropriate")
        elif Place_Panel == "n":
            print_pause("You step away from the pedestal")
        else:
            print_pause("What you have decided is not possible, "
                        "please try again")
            green_room()
    elif "green" in correct_panels:
        print_pause("The correct panel has been placed here")
    else:
        print_pause("There is a blue panel in the pedestal")
        Panel = input("Would you like to remove the panel? Y/N\n ").lower()
        if Panel == "y":
            items.append("blue")
        elif Panel == "n":
            print_pause("You step away from the pedestal")
        else:
            print_pause("What you have decided is not possible")
            green_room()

    print_pause("There is nothing more to do here, "
                "you return to the centre of the room.")
    Win()
    Centre_Return()


def red_room():
    global count_correct
    print_pause("You approach the redly lit enclave")
    if "yellow" in items and "red" not in correct_panels:
        print_pause("The pedestal is empty")
        Place_Panel = input("Would you like to place a new "
                            "panel in the pedestal? Y/N\n ").lower()
        if Place_Panel == "y":
            print_pause("You search through your "
                        "inventory for an appropriate panel...")
            if "red" in items:
                print_pause("You place a red panel into the pedestal")
                count_correct += 1
                correct_panels.append("red")
            else:
                print_pause("Nothing you have seems appropriate")
        elif Place_Panel == "n":
            print_pause("You step away from the pedestal")
        else:
            print_pause("What you have decided is "
                        "not possible, please try again")
            red_room()
    elif "red" in correct_panels:
        print_pause("The correct panel has been placed here")
    else:
        print_pause("There is a yellow panel in the pedestal")
        Panel = input("Would you like to remove the panel? Y/N\n").lower()
        if Panel == "y":
            items.append("yellow")
        elif Panel == "n":
            print_pause("You step away from the pedestal")
        else:
            print_pause("What you have decided is not possible")
            red_room()

    print_pause("There is nothing more to do here, you "
                "return to the centre of the room.")
    Win()
    Centre_Return()


def blue_room():
    global count_correct
    print_pause("You approach the blue lit enclave")
    if "red" in items and "blue" not in correct_panels:
        print_pause("The pedestal is empty")
        Place_Panel = input("Would you like to place a new panel "
                            "in the pedestal? Y/N\n ").lower()
        if Place_Panel == "y":
            print_pause("You search through your inventory "
                        "for an appropriate panel...")
            if "blue" in items:
                print_pause("You place a blue panel into the pedestal")
                count_correct += 1
                correct_panels.append("blue")
            else:
                print_pause("Nothing you have seems appropriate")
        elif Place_Panel == "n":
            print_pause("You step away from the pedestal")
        else:
            print_pause("What you have decided is not "
                        "possible, please try again")
            blue_room()
    elif "blue" in correct_panels:
        print_pause("The correct panel has been placed here")
    else:
        print_pause("There is a red panel in the pedestal")
        Panel = input("Would you like to remove the panel? Y/N\n ").lower()
        if Panel == "y":
            items.append("red")
        elif Panel == "n":
            print_pause("You step away from the pedestal")
        else:
            print_pause("What you have decided is not possible")
            blue_room()

    print_pause("There is nothing more to do here, you "
                "return to the centre of the room.")
    Win()
    Centre_Return()


def white_room():
    global count_correct
    print_pause("You approach the white lit enclave")
    if "green" in items and "white" not in correct_panels:
        print_pause("The pedestal is empty")
        Place_Panel = input("Would you like to place a new panel "
                            "in the pedestal? Y/N\n ").lower()
        if Place_Panel == "y":
            print_pause("You search through your inventory for "
                        "an appropriate panel...")
            if "white" in items:
                print_pause("You place a white panel into the pedestal")
                count_correct += 1
                correct_panels.append("white")
            else:
                print_pause("Nothing you have seems appropriate")
        elif Place_Panel == "n":
            print_pause("You step away from the pedestal")
        else:
            print_pause("What you have decided is "
                        "not possible, please try again")
            white_room()

    elif "white" in correct_panels:
        print_pause("The correct panel has been placed here")
    else:
        print_pause("There is a green panel in the pedestal")
        Panel = input("Would you like to remove the panel? Y/N\n ").lower()
        if Panel == "y":
            items.append("green")
        elif Panel == "n":
            print_pause("You step away from the pedestal")
        else:
            print_pause("What you have decided is not possible")
            white_room()

    print_pause("There is nothing more to do here, you "
                "return to the centre of the room.")
    Win()
    Centre_Return()


def yellow_room():
    global count_correct
    print_pause("You approach the yellow lit enclave")
    if "white" in items and "yellow" not in correct_panels:
        print_pause("The pedestal is empty")
        Place_Panel = input("Would you like to place a new panel "
                            "in the pedestal? Y/N\n ").lower()
        if Place_Panel == "y":
            print_pause("You search through your inventory "
                        "for an appropriate panel...")
            if "yellow" in items:
                print_pause("You place a yellow panel into the pedestal")
                count_correct += 1
                correct_panels.append("yellow")
            else:
                print_pause("Nothing you have seems appropriate")
        elif Place_Panel == "n":
            print_pause("You step away from the pedestal")
        else:
            print_pause("What you have decided is not "
                        "possible, please try again")
            yellow_room()
    elif "yellow" in correct_panels:
        print_pause("The correct panel has been placed here")
    else:
        print_pause("There is a white panel in the pedestal")
        Panel = input("Would you like to remove the panel? Y/N\n ").lower()
        if Panel == "y":
            items.append("white")
        elif Panel == "n":
            print_pause("You step away from the pedestal")
        else:
            print_pause("What you have decided is not possible")
            yellow_room()

    print_pause("There is nothing more to do here, you "
                "return to the centre of the room.")
    Win()
    Centre_Return()


while Game < 5:
    # Introduction
    intro()
    # Centre Return
    Centre_Return()
    replay = input("Would you like to play again? Y/N\n ").lower()
    if replay == "n":
        print_pause("Thank you for playing!")
        Game += 10
    elif replay == "y":
        Reset()
        intro()
        Centre_Return()
