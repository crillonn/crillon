const grid = $("#pixelCanvas"); //Create table element globally

const submit = $("input[type='submit']").on("click",function() {
  event.preventDefault();
  console.log("The submit has been clicked!");

  const height = $("#inputHeight").val(); // Returns the selected height value
  const width = $("#inputWidth").val(); // Returns the selected width value
  console.log(height+" "+width); // Displays in the console the selected height and width values

  grid.empty(); //Clear previous grid
  makeGrid(height,width);

});

// When size is submitted by the user, call makeGrid()

//Make The Grid To Be Coloured In
//Creation of the grid operates as such - Creation of rows as X, append each new data cell as per Y
function makeGrid(height,width) {
  for(r =0; r<height ;r++) {

    //Add Rows to the grid
    grid.append($("<tr> </tr>"));
    for(c =0; c<width; c++) {

          //Add Columns to the rows
          $("tr").last().append($("<td> </td>"));

          }
  }
  console.log(height+" "+width); //Displays in the console the selected height and width values - Verifying operationality

}

// Changing the colour of each cell - Listener = click/Event Delegation must be utilized here.
//Color to be chosen must be decided at the point in time to what the chosen color is.
grid.on("click", "td", function() {

  $(this).css("background-color",$("#colorPicker").val());

});
